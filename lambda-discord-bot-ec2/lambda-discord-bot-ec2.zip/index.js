const axios = require('axios').default;

exports.handler = async (event) => {
    // // TODO implement
    // const response = {
    //     statusCode: 200,
    //     body: JSON.stringify('Hello from Lambda!'),
    // };
    // return response;

    let response = {
        "content": "Hello from Lambda!"
    }

    const body = JSON.parse(event.Records[0].Sns.Message)
    // const response = await action(body)
    axios.patch(`https://discord.com/api/v10/webhooks/${body.application_id}/${body.token}/messages/@original`, response)
      .then(function (response) {
        console.log(response);
      })
      .catch(function (error) {
        console.log(error);
      });
};
